import Foundation

struct MeoGo: Codable {
  let value: [Content]
  let nextLink: String

  enum CodingKeys: String, CodingKey {
    case value
    case nextLink = "odata.nextLink"
  }
}

extension MeoGo {
  struct Content: Codable {
    let id: Int
    let title: String
    let callLetter: String

    enum CodingKeys: String, CodingKey {
      case id = "Id"
      case title = "Title"
      case callLetter = "CallLetter"
    }
  }
}
