import Foundation
import UIKit

extension UIColor {
  static let labelColor = UIColor(red: 54.0/255.0, green: 54.0/255.0, blue: 54.0/255.0, alpha: 1.0)
}

extension CGFloat {
  static let titleSize: CGFloat = 8.0
  static let epgNowSize: CGFloat = 14.0
  static let epgNextSize: CGFloat = 10.0
  static let imageAspectRatio: CGFloat = 16.0 / 9.0
  static let labelSpacing: CGFloat = 3.0
}

extension Sequence {
    func asyncMap<T>(
        _ transform: (Element) async throws -> T
    ) async rethrows -> [T] {
        var values = [T]()

        for element in self {
            try await values.append(transform(element))
        }

        return values
    }
}

extension Collection {
    subscript (safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}
