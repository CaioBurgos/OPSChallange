import UIKit

class ListViewController: UIViewController {

  private lazy var tableView: UITableView = {
    let tableView = UITableView()
    tableView.delegate = self
    tableView.dataSource = self
    tableView.register(ListTableViewCell.self, forCellReuseIdentifier: ListTableViewCell.reusableIdentifier)
    tableView.translatesAutoresizingMaskIntoConstraints = false
    tableView.backgroundColor = .lightGray
    tableView.separatorStyle = .none
    return tableView
  }()

  private var listContent = [ListContent]()

  private let viewModel = ListViewModel()

  override func viewDidLoad() {
    super.viewDidLoad()
    title = "NowAndNext"
    setup()
    bind()
    viewModel.viewDidLoad()
  }

  private func setup() {
    view.backgroundColor = .white

    view.addSubview(tableView)
    NSLayoutConstraint.activate([
      tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
      tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
      tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
      tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
    ])
  }

  private func bind() {
    viewModel.onLoad = { [weak self] content in
      DispatchQueue.main.async {
        self?.loadContent(content)
      }
    }

    viewModel.onLoadMore = { [weak self] content in
      DispatchQueue.main.async {
        self?.loadMore(content)
      }
    }

    viewModel.onError = { [weak self] in self?.presentError() }
  }

  private func loadContent(_ content: [ListContent]) {
    self.listContent = content
    tableView.reloadData()
  }

  private func loadMore(_ content: [ListContent]) {
    let currentCount = listContent.count
    self.listContent += content

    var i = 0
    let indexes = content.map { _ -> IndexPath in
      let index = IndexPath(row: currentCount + i, section: 0)
      i += 1
      return index
    }

    tableView.beginUpdates()
    tableView.insertRows(at: indexes, with: .automatic)
    tableView.endUpdates()
  }

  private func presentError() {
    let alert = UIAlertController(title: "Erro ao buscar canais", message: "Verifique a conexão com a internet e tente novamente.", preferredStyle: .alert)
    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
    alert.addAction(UIAlertAction(title: "Tentar novamente", style: .default, handler: { [weak self] _ in self?.viewDidLoad() }))
    self.present(alert, animated: true, completion: nil)
  }
}

extension ListViewController: UITableViewDataSource {
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    listContent.count
  }

  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    guard let cell = tableView.dequeueReusableCell(withIdentifier: ListTableViewCell.reusableIdentifier, for: indexPath) as? ListTableViewCell,
          let content = listContent[safe: indexPath.row] else {
      return UITableViewCell()
    }
    cell.setContent(content)
    return cell
  }
}

extension ListViewController: UITableViewDelegate {
  func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
    guard indexPath.row > listContent.count - 3 else { return }
    viewModel.loadMore()
  }

  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    tableView.deselectRow(at: indexPath, animated: true)
  }
}
