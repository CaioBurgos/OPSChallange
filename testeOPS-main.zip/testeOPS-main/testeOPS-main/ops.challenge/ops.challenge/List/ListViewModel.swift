import Foundation

final class ListViewModel {

  var onLoad: (([ListContent]) -> Void)?
  var onLoadMore: (([ListContent]) -> Void)?
  var onError: (() -> Void)?

  private var lastNextLink: String?

  func viewDidLoad() {
    Task {
      do {
        let result = try await loadContent()
        onLoad?(result)
      } catch {
        onError?()
      }
    }
  }

  func loadMore() {
    Task {
      try await loadMoreContent()
    }
  }

  private func loadContent(_ url: URL? = nil) async throws -> [ListContent] {
    let meoGoContent = try await fetchMeoGo(url)
    lastNextLink = meoGoContent.nextLink

    let contentList: [ListContent] = try await meoGoContent.value.asyncMap { content in
      let nowAndNext = try await self.fetchNowAndNext(callLetter: content.callLetter)
      let epgNow = nowAndNext.value[0]
      let epgNext = nowAndNext.value[1]

      let image = Self.images(title: epgNow.title, callLetter: content.callLetter)

      return ListContent(
        imageURL: image,
        title: content.title,
        epgNow: epgNow.title,
        epgNext: epgNext.title)
    }

    return contentList
  }

  private func loadMoreContent() async throws {
    guard let lastNextLink = lastNextLink, let url = URL(string: lastNextLink) else { return }
    let result = try await loadContent(url)
    onLoadMore?(result)
  }

  private func fetchMeoGo(_ url: URL? = nil) async throws -> MeoGo {
    let url = url ?? Self.meoGoURL()
    let result: MeoGo = try await performCall(url: url)
    return result
  }

  private func fetchNowAndNext(callLetter: String) async throws -> EpgNowNext {
    let url = Self.nowAndNextURL(callLetter: callLetter)
    let result: EpgNowNext = try await performCall(url: url)
    return result
  }

  private func performCall<T: Codable>(url: URL) async throws -> T {
    let urlSession = URLSession.shared
    let (data, _) = try await urlSession.data(from: url)
    let decoder = JSONDecoder()
    let result = try decoder.decode(T.self, from: data)
    return result
  }
}

extension ListViewModel {
  static func meoGoURL() -> URL {
    return URL(string: "http://ott.online.meo.pt/catalog/v9/Channels?UserAgent=IOS&$filter=substringof(%27MEO_Mobile%27,AvailableOnChannels)%20and%20IsAdult%20eq%20false&$orderby=ChannelPosition%20asc&$inlinecount=allpages")!
  }

  static func nowAndNextURL(callLetter: String) -> URL {
    let callLetterNormalised = callLetter.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
    return URL(string: "http://ott.online.meo.pt/Program/v9/Programs/NowAndNextLiveChannelPrograms?UserAgent=IOS&$filter=CallLetter%20eq%20%27\(callLetterNormalised)%27&$orderby=StartDate%20asc")!
  }

  static func images(title: String, callLetter: String) -> URL {
    let callLetterNormalised = callLetter.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
    let titleNormalised = title.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
    let string = "http://213.13.23.60/wp/cdn-images.online.meo.pt/eemstb/ImageHandler.ashx?evTitle=\(titleNormalised)&chCallLetter=\(callLetterNormalised)&profile=16_9&width=320"
    return URL(string: string)!
  }
}
