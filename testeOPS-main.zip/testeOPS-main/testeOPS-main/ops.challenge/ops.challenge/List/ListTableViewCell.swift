import Foundation
import UIKit
import Kingfisher

final class ListTableViewCell: UITableViewCell {

  static let reusableIdentifier = "ListTableViewCell"

  // MARK: - Internal properties
  private let channelImageView: UIImageView = {
    let imageView = UIImageView()
    imageView.contentMode = .scaleAspectFit
    imageView.translatesAutoresizingMaskIntoConstraints = false
    return imageView
  }()

  private let channelLabel: UILabel = {
    let label = UILabel()
    label.textColor = .labelColor
    label.font = label.font.withSize(.titleSize)
    label.translatesAutoresizingMaskIntoConstraints = false
    return label
  }()

  private let epgNowLabel: UILabel = {
    let label = UILabel()
    label.textColor = .labelColor
    label.font = label.font.withSize(.epgNowSize)
    label.translatesAutoresizingMaskIntoConstraints = false
    return label
  }()

  private let epgNextLabel: UILabel = {
    let label = UILabel()
    label.textColor = .labelColor
    label.font = label.font.withSize(.epgNextSize)
    label.translatesAutoresizingMaskIntoConstraints = false
    return label
  }()

  private let labelStackView: UIStackView = {
    let stackView = UIStackView()
    stackView.axis = .vertical
    stackView.spacing = .labelSpacing
    stackView.translatesAutoresizingMaskIntoConstraints = false
    stackView.distribution = .equalCentering
    return stackView
  }()

  private let cardView: UIView = {
    let view = UIView()
    view.translatesAutoresizingMaskIntoConstraints = false
    return view
  }()

  func setContent(_ content: ListContent) {
    channelImageView.kf.setImage(with: content.imageURL)
    channelLabel.text = content.title
    epgNowLabel.text = content.epgNow
    epgNextLabel.text = content.epgNext
  }

  // MARK: - Initialiser
  override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
    super.init(style: style, reuseIdentifier: reuseIdentifier)
    setup()
    layout()
  }

  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }

  override func prepareForReuse() {
    super.prepareForReuse()
    channelImageView.image = nil
  }

  private func setup() {
    contentView.addSubview(cardView)
    [channelImageView, labelStackView].forEach(cardView.addSubview)
    [channelLabel, epgNowLabel, epgNextLabel].forEach(labelStackView.addArrangedSubview)
    backgroundColor = .clear
    cardView.backgroundColor = .white
    cardView.layer.cornerRadius = 4.0
    cardView.clipsToBounds = true
  }

  private func layout() {
    channelImageView.setContentCompressionResistancePriority(.defaultHigh, for: .horizontal)

    NSLayoutConstraint.activate([
      cardView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 3.0),
      cardView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -3.0),
      cardView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 2.0),
      cardView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -2.0),

      channelImageView.topAnchor.constraint(equalTo: cardView.topAnchor),
      channelImageView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor),
      channelImageView.bottomAnchor.constraint(equalTo: cardView.bottomAnchor),
      channelImageView.heightAnchor.constraint(equalToConstant: 70.0),
      channelImageView.widthAnchor.constraint(equalTo: cardView.heightAnchor, multiplier: .imageAspectRatio),

      labelStackView.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 2.0),
      labelStackView.leadingAnchor.constraint(equalTo: channelImageView.trailingAnchor, constant: 10.0),
      labelStackView.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -5.0),
      labelStackView.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -5.0),
    ])
  }
}
