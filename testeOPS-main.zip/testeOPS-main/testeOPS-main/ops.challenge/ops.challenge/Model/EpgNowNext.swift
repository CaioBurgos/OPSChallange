import Foundation

struct EpgNowNext: Codable {
  let value: [Content]
}

extension EpgNowNext {
  struct Content: Codable {
    let id: String
    let title: String
    let callLetter: String

    enum CodingKeys: String, CodingKey {
      case id = "Id"
      case title = "Title"
      case callLetter = "CallLetter"
    }
  }
}
