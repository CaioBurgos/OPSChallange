import Foundation

struct ListContent {
  let imageURL: URL
  let title: String
  let epgNow: String
  let epgNext: String
}
